# Daemon Queue ABI

ABI includes version, struct_size, client_id, generation, job_id, status, timeouts, error codes.

# Failure Modes

Daemon crash, timeout, stale generation, CRC mismatch, queue full, saturated slots.

# hololinux-integration Architecture

Linux kernel/user integration for Holo Suite.

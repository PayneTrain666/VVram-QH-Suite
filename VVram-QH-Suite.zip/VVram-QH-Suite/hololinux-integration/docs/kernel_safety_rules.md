# Kernel Safety Rules

No CUDA runtime in kernel. Exact recovery for zswap. Bounded waits only.

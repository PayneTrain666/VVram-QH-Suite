# Stats Bridge

Daemon pushes hot/saturated slot state to correct kernel budget policy.

# Exact Mode Requirement

Linux memory pages must recover byte-identically.

# zswap Backend

Exact raw first, exact QH+residual second. Approximate-only sparse mode forbidden.

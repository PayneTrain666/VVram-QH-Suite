#include "../../include/kernel/holoram_policy.h"
/* Inline routing lives in header. */

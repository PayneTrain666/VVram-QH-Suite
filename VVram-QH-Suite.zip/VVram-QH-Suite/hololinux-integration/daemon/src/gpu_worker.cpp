/* TODO(v0.1): GPU worker lives in userspace daemon only. */

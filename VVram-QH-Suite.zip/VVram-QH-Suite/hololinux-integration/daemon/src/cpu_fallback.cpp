/* TODO(v0.1): CPU fallback path. */

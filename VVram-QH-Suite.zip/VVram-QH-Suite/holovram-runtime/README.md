# holovram-runtime

Virtual video RAM runtime for Holo Suite.

This is not fake VRAM. It is a tile/resource residency runtime using real VRAM as hot tier and QH system RAM as warm backing tier.

# Graphics API Mapping

Planned backends: CUDA, Vulkan sparse resources, D3D12 tiled resources.

# holovram-runtime Architecture

Manages virtual resource residency using real VRAM hot tier and QH system RAM warm tier.

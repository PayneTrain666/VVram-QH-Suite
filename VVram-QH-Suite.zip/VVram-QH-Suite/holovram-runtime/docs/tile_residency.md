# Tile Residency

States: ResidentDisk, ResidentQHSystem, DecodePending, UploadPending, ResidentVRAM, Evicted, Failed.

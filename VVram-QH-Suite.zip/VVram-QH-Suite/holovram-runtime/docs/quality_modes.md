# Quality Modes

Approximate modes are acceptable only where metrics are reported.

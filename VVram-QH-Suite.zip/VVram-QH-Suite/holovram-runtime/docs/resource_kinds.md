# Resource Kinds

Texture2D, Texture3D, Buffer, Meshlet, EmbeddingBlock, ModelWeightTile, VideoTile, GaussianSplatChunk.

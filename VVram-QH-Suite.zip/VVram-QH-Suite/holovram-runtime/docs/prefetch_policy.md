# Prefetch Policy

Uses camera path, visible tile history, mip demand, target frame, AI layer order, and resource priority.

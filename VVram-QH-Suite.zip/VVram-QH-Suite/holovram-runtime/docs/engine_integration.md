# Engine Integration

Integrates as a streaming/resource layer and should not require shaders to read QH memory directly.

#pragma once
#include "holovram/hv_residency.h"
namespace holovram { struct FrameMetrics{double frame_ms=0.0,decode_ms=0.0,upload_ms=0.0; ResidencyStats residency{};}; }

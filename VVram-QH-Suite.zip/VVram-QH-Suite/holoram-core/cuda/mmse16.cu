// TODO(v0.1): implement mmse16.cu.
extern "C" void holoram_mmse16_stub() {}

// TODO(v0.1): implement substrate_kernels.cu.
extern "C" void holoram_substratekernels_stub() {}

// TODO(v0.1): implement sparse_write.cu.
extern "C" void holoram_sparsewrite_stub() {}

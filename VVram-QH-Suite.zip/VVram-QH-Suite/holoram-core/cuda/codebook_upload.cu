// TODO(v0.1): implement codebook_upload.cu.
extern "C" void holoram_codebookupload_stub() {}

// TODO(v0.1): implement spectral_shrink.cu.
extern "C" void holoram_spectralshrink_stub() {}

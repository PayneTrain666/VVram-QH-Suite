// TODO(v0.1): implement sic.cu.
extern "C" void holoram_sic_stub() {}

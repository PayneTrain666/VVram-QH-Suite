// TODO(v0.1): implement batch_scheduler.cu.
extern "C" void holoram_batchscheduler_stub() {}

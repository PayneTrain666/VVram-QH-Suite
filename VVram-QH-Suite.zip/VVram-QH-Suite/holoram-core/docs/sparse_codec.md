# Sparse Codec

Sparse mode keeps only top-K spectral bins and is approximate unless residual protected.

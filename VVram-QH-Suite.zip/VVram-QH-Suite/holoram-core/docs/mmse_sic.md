# MMSE and SIC

MMSE reduces crosstalk. SIC can improve recovery under interference.

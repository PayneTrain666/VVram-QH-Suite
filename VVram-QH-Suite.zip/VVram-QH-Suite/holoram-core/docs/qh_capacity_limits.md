# QH Capacity Limits

Capacity is limited by code coherence, slot energy, active channels, quantization noise, sparse K, and acceptable error metric.

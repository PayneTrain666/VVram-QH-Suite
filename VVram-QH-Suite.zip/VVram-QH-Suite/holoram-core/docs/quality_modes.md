# Quality Modes

Exact modes must recover bytes exactly. Approximate modes must report metrics.

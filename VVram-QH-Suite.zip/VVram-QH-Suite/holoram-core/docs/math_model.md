# QH Math Model

`H_s[k] += alpha * U_c[k] * X[k]`

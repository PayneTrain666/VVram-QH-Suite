# holoram-core Architecture

Reusable QH memory engine. No graphics or Linux kernel code belongs here.

# WriteMap Format

Every logical object stored in the substrate needs slot/channel/generation metadata.

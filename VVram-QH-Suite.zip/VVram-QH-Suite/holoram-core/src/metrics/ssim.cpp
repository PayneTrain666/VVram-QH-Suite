#include "holoram/qh_metrics.h"
namespace holoram { double ssim_placeholder(const std::uint8_t*,const std::uint8_t*,std::uint32_t){ return 0.0; } }

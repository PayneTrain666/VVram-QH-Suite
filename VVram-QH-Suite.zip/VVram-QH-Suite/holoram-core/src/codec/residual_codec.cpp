#include <cstdint>
#include <vector>
namespace holoram { std::vector<std::uint8_t> compute_residual_placeholder(const std::uint8_t* original,const std::uint8_t* reconstructed,std::uint32_t n){ std::vector<std::uint8_t> residual(n); for(std::uint32_t i=0;i<n;++i) residual[i]=static_cast<std::uint8_t>(original[i]^reconstructed[i]); return residual; } }

#include <iostream>
int main(){ std::cout << "TODO(v0.1): benchmark\n"; return 0; }

# holoram-core

Quantum-holographic memory core library for Holo Suite.

Owns codebooks, codecs, demix, substrate, policy, WriteMap/WAL, metrics, tests, and benchmarks.

## Non-goals

No graphics APIs, no Linux kernel code, no zswap-specific logic.

## Build

```bash
cmake -S . -B build -DHOLO_ENABLE_CUDA=OFF
cmake --build build -j
ctest --test-dir build
```

# Repo Manifest

Generated: 2026-04-24 14:43:25 Australia/Sydney

## Suite

- `README.md`
- `VERSION`
- `.gitignore`
- `docs/suite_architecture.md`
- `docs/repo_boundaries.md`
- `docs/roadmap.md`
- `scripts/init_repos.sh`
- `CHAT_CONTENT_HOLO_SUITE_2026-04-24.md`
- `GITHUB_PUSH_INSTRUCTIONS.md`

## Repos

- `holoram-core/`
- `holovram-runtime/`
- `hololinux-integration/`

## Notes

This package is a structured, organized snapshot of the Holo Suite repo split and skeleton source content generated on 2026-04-24.

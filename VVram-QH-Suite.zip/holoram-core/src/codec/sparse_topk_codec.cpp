#include "holoram/qh_codec.h"
#include "holoram/qh_metrics.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

namespace holoram {

std::int8_t clamp_i8(int v);
std::int16_t clamp_i16(int v);
float choose_i8_scale(float max_abs);
float choose_i16_scale(float max_abs);

std::vector<std::uint8_t> compute_xor_residual(const std::uint8_t* original, const std::uint8_t* reconstructed, std::uint32_t n);
std::vector<std::uint8_t> apply_xor_residual(const std::uint8_t* reconstructed, const std::uint8_t* residual, std::uint32_t n);
std::vector<std::uint8_t> maybe_compress_residual(const std::vector<std::uint8_t>& residual, HoloResidualCompression requested, HoloResidualCompression& used);
bool decompress_residual_payload(const std::uint8_t* payload, std::uint32_t payload_bytes, std::uint32_t expected_bytes, HoloResidualCompression compression, std::vector<std::uint8_t>& out);

namespace {

constexpr float kPi = 3.14159265358979323846f;

template <typename T>
void append_pod(std::vector<std::uint8_t>& out, const T& value) {
    const auto* p = reinterpret_cast<const std::uint8_t*>(&value);
    out.insert(out.end(), p, p + sizeof(T));
}

template <typename T>
bool read_pod(const std::uint8_t* payload, std::uint32_t payload_bytes, std::uint32_t& offset, T& out) {
    if (offset + sizeof(T) > payload_bytes) {
        return false;
    }
    std::memcpy(&out, payload + offset, sizeof(T));
    offset += static_cast<std::uint32_t>(sizeof(T));
    return true;
}

std::uint32_t safe_q_from_cfg(const HoloCodecConfig& cfg, const HoloCodebook& codebook) {
    const auto cq = codebook.config().q;
    if (cfg.q != 0 && cfg.q != cq) {
        throw std::invalid_argument("HoloCodecConfig.q must match HoloCodebookConfig.q");
    }
    return cq;
}

std::uint16_t quant_bits_from_mode(HoloQuantMode mode) {
    switch (mode) {
        case HoloQuantMode::Int8Complex:
            return 8;
        case HoloQuantMode::Int16Complex:
            return 16;
        default:
            return 16;
    }
}

float byte_to_signal(std::uint8_t v) {
    return (static_cast<float>(v) - 127.5f) / 127.5f;
}

std::uint8_t signal_to_byte(float x) {
    const float y = (x * 127.5f) + 127.5f;
    const int rounded = static_cast<int>(std::lround(y));
    const int clamped = std::max(0, std::min(255, rounded));
    return static_cast<std::uint8_t>(clamped);
}

std::vector<Complex32> dft_real_signal(const std::vector<float>& x) {
    const std::uint32_t q = static_cast<std::uint32_t>(x.size());
    std::vector<Complex32> out(q);
    const float norm = 1.0f / std::sqrt(static_cast<float>(q));

    for (std::uint32_t m = 0; m < q; ++m) {
        Complex32 acc(0.0f, 0.0f);
        for (std::uint32_t n = 0; n < q; ++n) {
            const float phase = -2.0f * kPi * static_cast<float>(m) * static_cast<float>(n) / static_cast<float>(q);
            const Complex32 w(std::cos(phase), std::sin(phase));
            acc += x[n] * w;
        }
        out[m] = acc * norm;
    }

    return out;
}

std::vector<float> idft_to_real_signal(const std::vector<Complex32>& x) {
    const std::uint32_t q = static_cast<std::uint32_t>(x.size());
    std::vector<float> out(q, 0.0f);
    const float norm = 1.0f / std::sqrt(static_cast<float>(q));

    for (std::uint32_t n = 0; n < q; ++n) {
        Complex32 acc(0.0f, 0.0f);
        for (std::uint32_t m = 0; m < q; ++m) {
            const float phase = 2.0f * kPi * static_cast<float>(m) * static_cast<float>(n) / static_cast<float>(q);
            const Complex32 w(std::cos(phase), std::sin(phase));
            acc += x[m] * w;
        }
        out[n] = (acc * norm).real();
    }

    return out;
}

std::vector<float> make_signal_block(const std::uint8_t* decoded, std::uint32_t decoded_bytes, std::uint32_t block_idx, std::uint32_t q) {
    std::vector<float> signal(q, 0.0f);
    const std::uint32_t base = block_idx * q;

    for (std::uint32_t i = 0; i < q; ++i) {
        const std::uint32_t src = base + i;
        signal[i] = src < decoded_bytes ? byte_to_signal(decoded[src]) : 0.0f;
    }

    return signal;
}

void fill_sparse_block(HoloSparseBlock& block, const std::vector<Complex32>& encoded_coeffs, std::uint32_t q, std::uint16_t k, std::uint16_t qbits) {
    block = HoloSparseBlock{};
    block.q = static_cast<std::uint16_t>(q);
    block.k = k;
    block.qbits = qbits;

    std::vector<std::pair<float, std::uint16_t>> ranked;
    ranked.reserve(q);

    for (std::uint32_t i = 0; i < q; ++i) {
        ranked.emplace_back(std::norm(encoded_coeffs[i]), static_cast<std::uint16_t>(i));
    }

    std::partial_sort(ranked.begin(), ranked.begin() + k, ranked.end(), [](const auto& a, const auto& b) {
        return a.first > b.first;
    });

    float max_abs = 0.0f;
    for (std::uint16_t i = 0; i < k; ++i) {
        const auto idx = ranked[i].second;
        max_abs = std::max(max_abs, std::abs(encoded_coeffs[idx].real()));
        max_abs = std::max(max_abs, std::abs(encoded_coeffs[idx].imag()));
    }

    const float scale = qbits == 8 ? choose_i8_scale(max_abs) : choose_i16_scale(max_abs);
    block.scale = scale;

    for (std::uint16_t i = 0; i < k; ++i) {
        const auto idx = ranked[i].second;
        const auto coeff = encoded_coeffs[idx];

        block.idx[i] = idx;

        if (qbits == 8) {
            block.re[i] = static_cast<std::int16_t>(clamp_i8(static_cast<int>(std::lround(coeff.real() / scale))));
            block.im[i] = static_cast<std::int16_t>(clamp_i8(static_cast<int>(std::lround(coeff.imag() / scale))));
        } else {
            block.re[i] = clamp_i16(static_cast<int>(std::lround(coeff.real() / scale)));
            block.im[i] = clamp_i16(static_cast<int>(std::lround(coeff.imag() / scale)));
        }
    }
}

bool read_sparse_header(const std::uint8_t* payload, std::uint32_t payload_bytes, HoloSparsePayloadHeader& header) {
    if (payload_bytes < sizeof(HoloSparsePayloadHeader)) {
        return false;
    }

    std::memcpy(&header, payload, sizeof(header));

    return header.magic == HOLO_SPARSE_PAYLOAD_MAGIC &&
           header.version == 2 &&
           header.struct_size == sizeof(HoloSparsePayloadHeader) &&
           header.q != 0 &&
           header.k != 0 &&
           header.k <= HOLO_SPARSE_K_MAX &&
           header.block_count != 0;
}

std::vector<std::uint8_t> reconstruct_from_sparse_payload(
    const std::uint8_t* payload,
    std::uint32_t payload_bytes,
    const HoloCodebook& codebook,
    HoloError& error,
    std::uint32_t* sparse_end_offset = nullptr)
{
    error = HoloError::Ok;

    std::uint32_t offset = 0;
    HoloSparsePayloadHeader header{};

    if (!read_pod(payload, payload_bytes, offset, header)) {
        error = HoloError::DecodeFailed;
        return {};
    }

    if (header.magic != HOLO_SPARSE_PAYLOAD_MAGIC ||
        header.version != 2 ||
        header.struct_size != sizeof(HoloSparsePayloadHeader) ||
        header.q == 0 ||
        header.k == 0 ||
        header.k > HOLO_SPARSE_K_MAX ||
        header.block_count == 0) {
        error = HoloError::DecodeFailed;
        return {};
    }

    if (header.q != codebook.config().q || header.channel >= codebook.config().channels) {
        error = HoloError::InvalidArgument;
        return {};
    }

    const std::uint32_t sparse_bytes = header.block_count * static_cast<std::uint32_t>(sizeof(HoloSparseBlock));
    if (offset + sparse_bytes > payload_bytes) {
        error = HoloError::DecodeFailed;
        return {};
    }

    if (header.sparse_crc32 != 0) {
        const auto actual_crc = crc32_bytes(payload + offset, sparse_bytes);
        if (actual_crc != header.sparse_crc32) {
            error = HoloError::IntegrityCheckFailed;
            return {};
        }
    }

    const auto* code = codebook.channel(header.channel);
    std::vector<std::uint8_t> approx(header.decoded_bytes, 0);

    for (std::uint32_t b = 0; b < header.block_count; ++b) {
        HoloSparseBlock block{};

        if (!read_pod(payload, payload_bytes, offset, block)) {
            error = HoloError::DecodeFailed;
            return {};
        }

        if (block.magic != HOLO_SPARSE_BLOCK_MAGIC ||
            block.version != 1 ||
            block.struct_size != sizeof(HoloSparseBlock) ||
            block.q != header.q ||
            block.k != header.k) {
            error = HoloError::DecodeFailed;
            return {};
        }

        std::vector<Complex32> coeffs(header.q, Complex32{0.0f, 0.0f});

        for (std::uint16_t i = 0; i < block.k; ++i) {
            const std::uint16_t idx = block.idx[i];

            if (idx >= header.q) {
                error = HoloError::DecodeFailed;
                return {};
            }

            const Complex32 encoded{
                static_cast<float>(block.re[i]) * block.scale,
                static_cast<float>(block.im[i]) * block.scale};

            coeffs[idx] = encoded * std::conj(code[idx]);
        }

        const auto signal = idft_to_real_signal(coeffs);
        const std::uint32_t base = b * header.q;

        for (std::uint32_t i = 0; i < header.q; ++i) {
            const std::uint32_t dst = base + i;
            if (dst < header.decoded_bytes) {
                approx[dst] = signal_to_byte(signal[i]);
            }
        }
    }

    if (sparse_end_offset) {
        *sparse_end_offset = offset;
    }

    return approx;
}

} // namespace

HoloEncodeResult encode_sparse_topk(
    const void* decoded,
    std::uint32_t decoded_bytes,
    const HoloCodecConfig& cfg,
    const HoloCodebook& codebook,
    HoloChannelId channel)
{
    HoloEncodeResult out{};

    if (!decoded && decoded_bytes > 0) {
        out.error = HoloError::InvalidArgument;
        return out;
    }

    if (channel >= codebook.config().channels) {
        out.error = HoloError::InvalidArgument;
        return out;
    }

    std::uint32_t q = 0;
    try {
        q = safe_q_from_cfg(cfg, codebook);
    } catch (...) {
        out.error = HoloError::InvalidArgument;
        return out;
    }

    if (q > std::numeric_limits<std::uint16_t>::max()) {
        out.error = HoloError::UnsupportedMode;
        return out;
    }

    const std::uint16_t k = static_cast<std::uint16_t>(
        std::max<std::uint32_t>(1, std::min<std::uint32_t>(
            cfg.k_sparse,
            std::min<std::uint32_t>(q, HOLO_SPARSE_K_MAX))));

    const std::uint16_t qbits = quant_bits_from_mode(cfg.quant_mode);
    const std::uint32_t block_count = decoded_bytes == 0 ? 1u : ((decoded_bytes + q - 1u) / q);
    const auto* bytes = static_cast<const std::uint8_t*>(decoded);

    HoloSparsePayloadHeader payload_header{};
    payload_header.decoded_bytes = decoded_bytes;
    payload_header.q = q;
    payload_header.block_count = block_count;
    payload_header.k = k;
    payload_header.quant_bits = qbits;
    payload_header.codec_mode = static_cast<std::uint16_t>(cfg.codec_mode);
    payload_header.quant_mode = static_cast<std::uint16_t>(cfg.quant_mode);
    payload_header.demix_mode = static_cast<std::uint16_t>(cfg.demix_mode);
    payload_header.channel = channel;
    payload_header.residual_compression = static_cast<std::uint16_t>(cfg.residual_compression);

    if (cfg.enable_crc) {
        payload_header.decoded_crc32 = crc32_bytes(decoded, decoded_bytes);
    }

    append_pod(out.payload, payload_header);
    const std::uint32_t sparse_start = static_cast<std::uint32_t>(out.payload.size());

    const auto* code = codebook.channel(channel);

    for (std::uint32_t b = 0; b < block_count; ++b) {
        const auto signal = make_signal_block(bytes, decoded_bytes, b, q);
        auto coeffs = dft_real_signal(signal);

        for (std::uint32_t i = 0; i < q; ++i) {
            coeffs[i] *= code[i];
        }

        HoloSparseBlock block{};
        fill_sparse_block(block, coeffs, q, k, qbits);
        append_pod(out.payload, block);
    }

    if (cfg.enable_crc) {
        payload_header.sparse_crc32 = crc32_bytes(
            out.payload.data() + sparse_start,
            static_cast<std::uint32_t>(out.payload.size()) - sparse_start);
        std::memcpy(out.payload.data(), &payload_header, sizeof(payload_header));
    }

    if (cfg.codec_mode == HoloCodecMode::ExactQhResidual) {
        HoloError recon_error = HoloError::Ok;
        const auto approx = reconstruct_from_sparse_payload(
            out.payload.data(),
            static_cast<std::uint32_t>(out.payload.size()),
            codebook,
            recon_error);

        if (recon_error != HoloError::Ok || approx.size() != decoded_bytes) {
            out.error = HoloError::EncodeFailed;
            return out;
        }

        const auto residual = compute_xor_residual(bytes, approx.data(), decoded_bytes);

        HoloResidualCompression used_compression = HoloResidualCompression::None;
        const auto residual_payload = maybe_compress_residual(residual, cfg.residual_compression, used_compression);

        HoloResidualPayloadHeader rh{};
        rh.residual_payload_bytes = static_cast<std::uint32_t>(residual_payload.size());
        rh.residual_uncompressed_bytes = static_cast<std::uint32_t>(residual.size());
        rh.decoded_bytes = decoded_bytes;
        rh.compression = static_cast<std::uint16_t>(used_compression);

        if (cfg.enable_crc) {
            rh.residual_payload_crc32 = crc32_bytes(residual_payload.data(), static_cast<std::uint32_t>(residual_payload.size()));
            rh.decoded_crc32 = payload_header.decoded_crc32;
        }

        append_pod(out.payload, rh);
        out.payload.insert(out.payload.end(), residual_payload.begin(), residual_payload.end());
    }

    out.header.decoded_bytes = decoded_bytes;
    out.header.payload_bytes = static_cast<std::uint32_t>(out.payload.size());
    out.header.q = q;
    out.header.channels = codebook.config().channels;
    out.header.codec_mode = static_cast<std::uint16_t>(cfg.codec_mode);
    out.header.quant_mode = static_cast<std::uint16_t>(cfg.quant_mode);
    out.header.demix_mode = static_cast<std::uint16_t>(cfg.demix_mode);
    out.header.residual_compression = payload_header.residual_compression;
    out.header.decoded_crc32 = payload_header.decoded_crc32;
    out.header.payload_crc32 = cfg.enable_crc ? crc32_bytes(out.payload.data(), static_cast<std::uint32_t>(out.payload.size())) : 0u;
    out.error = HoloError::Ok;
    return out;
}

HoloDecodeResult decode_sparse_topk(
    const void* payload,
    std::uint32_t payload_bytes,
    const HoloCodecConfig& cfg,
    const HoloCodebook& codebook,
    HoloChannelId)
{
    HoloDecodeResult out{};

    if (!payload && payload_bytes > 0) {
        out.error = HoloError::InvalidArgument;
        return out;
    }

    const auto* bytes = static_cast<const std::uint8_t*>(payload);

    HoloSparsePayloadHeader sparse_header{};
    if (!read_sparse_header(bytes, payload_bytes, sparse_header)) {
        out.error = HoloError::DecodeFailed;
        return out;
    }

    HoloError err = HoloError::Ok;
    std::uint32_t sparse_end_offset = 0;

    auto approx = reconstruct_from_sparse_payload(
        bytes,
        payload_bytes,
        codebook,
        err,
        &sparse_end_offset);

    if (err != HoloError::Ok) {
        out.error = err;
        return out;
    }

    if (cfg.codec_mode != HoloCodecMode::ExactQhResidual) {
        out.decoded = std::move(approx);
        out.error = HoloError::Ok;
        return out;
    }

    HoloResidualPayloadHeader rh{};
    if (!read_pod(bytes, payload_bytes, sparse_end_offset, rh)) {
        out.error = HoloError::DecodeFailed;
        return out;
    }

    if (rh.magic != HOLO_RESIDUAL_MAGIC ||
        rh.version != 2 ||
        rh.struct_size != sizeof(HoloResidualPayloadHeader) ||
        rh.decoded_bytes != approx.size() ||
        sparse_end_offset + rh.residual_payload_bytes > payload_bytes) {
        out.error = HoloError::DecodeFailed;
        return out;
    }

    const auto* residual_payload = bytes + sparse_end_offset;

    if (rh.residual_payload_crc32 != 0) {
        const auto actual_crc = crc32_bytes(residual_payload, rh.residual_payload_bytes);
        if (actual_crc != rh.residual_payload_crc32) {
            out.error = HoloError::IntegrityCheckFailed;
            return out;
        }
    }

    std::vector<std::uint8_t> residual;
    const auto compression = static_cast<HoloResidualCompression>(rh.compression);

    if (!decompress_residual_payload(
            residual_payload,
            rh.residual_payload_bytes,
            rh.residual_uncompressed_bytes,
            compression,
            residual)) {
        out.error = HoloError::DecodeFailed;
        return out;
    }

    out.decoded = apply_xor_residual(
        approx.data(),
        residual.data(),
        static_cast<std::uint32_t>(residual.size()));

    if (rh.decoded_crc32 != 0) {
        const auto actual_crc = crc32_bytes(out.decoded.data(), static_cast<std::uint32_t>(out.decoded.size()));
        if (actual_crc != rh.decoded_crc32) {
            out.error = HoloError::IntegrityCheckFailed;
            return out;
        }
    }

    out.error = HoloError::Ok;
    return out;
}

} // namespace holoram

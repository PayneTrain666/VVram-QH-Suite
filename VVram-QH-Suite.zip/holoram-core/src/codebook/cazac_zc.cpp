#include "holoram/qh_codebook.h"

#include <cmath>
#include <stdexcept>

namespace holoram {

namespace {

constexpr float kPi = 3.14159265358979323846f;

Complex32 cis(float phase) {
    return Complex32(std::cos(phase), std::sin(phase));
}

float unit_phase_from_hash(std::uint32_t x) {
    return 2.0f * kPi * static_cast<float>(x) / static_cast<float>(0xFFFFFFFFu);
}

} // namespace

HoloCodebook::HoloCodebook(HoloCodebookConfig cfg) : cfg_(cfg) {
    if (cfg_.q == 0 || cfg_.channels == 0) {
        throw std::invalid_argument("HoloCodebook requires q > 0 and channels > 0");
    }

    if (cfg_.q < 8) {
        throw std::invalid_argument("HoloCodebook q is too small; minimum supported q is 8");
    }

    if (cfg_.channels > cfg_.q) {
        throw std::invalid_argument("HoloCodebook channels must be <= q for v0.1 CPU codebooks");
    }

    if (cfg_.strategy == HoloCodeStrategy::CazacZc) {
        build_cazac_zc();
    } else if (cfg_.strategy == HoloCodeStrategy::MubDft) {
        build_mub_dft();
    } else {
        throw std::invalid_argument("Unsupported HoloCodeStrategy");
    }

    if (cfg_.strict_validation) {
        const auto validation = validate();
        if (validation.quality == HoloCodebookQuality::Failed) {
            throw std::runtime_error("HoloCodebook validation failed: " + validation.message);
        }
    }
}

const Complex32* HoloCodebook::channel(std::uint32_t c) const {
    if (c >= cfg_.channels) {
        throw std::out_of_range("HoloCodebook channel index out of range");
    }
    return &codes_.at(static_cast<std::size_t>(c) * cfg_.q);
}

void HoloCodebook::build_cazac_zc() {
    codes_.assign(static_cast<std::size_t>(cfg_.channels) * cfg_.q, Complex32{1.0f, 0.0f});

    for (std::uint32_t c = 0; c < cfg_.channels; ++c) {
        // ZC/CAZAC-inspired quadratic chirp plus deterministic phase dithering.
        // The dither prevents duplicate/high-coherence channels for power-of-two Q.
        const std::uint32_t root = 1u + 2u * ((cfg_.seed + cfg_.salt + c) % (cfg_.q / 2u));

        for (std::uint32_t k = 0; k < cfg_.q; ++k) {
            const float chirp_phase =
                -kPi * static_cast<float>(root) * static_cast<float>(k) * static_cast<float>(k + 1u) / static_cast<float>(cfg_.q);

            const std::uint32_t h = qh_mix32(
                cfg_.seed ^
                (cfg_.salt * 0x9e3779b9u) ^
                (c * 0x85ebca6bu) ^
                (k * 0xc2b2ae35u));

            const float dither_phase = unit_phase_from_hash(h);
            codes_[static_cast<std::size_t>(c) * cfg_.q + k] = cis(chirp_phase + dither_phase);
        }
    }
}

} // namespace holoram

#include "holoram/qh_codebook.h"

#include <cmath>

namespace holoram {

namespace {

constexpr float kPi = 3.14159265358979323846f;

Complex32 cis_mub(float phase) {
    return Complex32(std::cos(phase), std::sin(phase));
}

} // namespace

void HoloCodebook::build_mub_dft() {
    codes_.assign(static_cast<std::size_t>(cfg_.channels) * cfg_.q, Complex32{1.0f, 0.0f});

    // DFT-row phase codes with seed/salt-derived permutation.
    // Distinct DFT rows are orthogonal, which gives a strong low-coherence baseline.
    const std::uint32_t start = qh_mix32(cfg_.seed ^ (cfg_.salt + 0x9e3779b9u)) % cfg_.q;
    std::uint32_t step = (qh_mix32(cfg_.salt ^ (cfg_.seed + 0x85ebca6bu)) % cfg_.q) | 1u;
    if (step == 0) {
        step = 1;
    }

    for (std::uint32_t c = 0; c < cfg_.channels; ++c) {
        const std::uint32_t slope = (start + c * step) % cfg_.q;
        const std::uint32_t phase_seed = qh_mix32(cfg_.seed ^ (cfg_.salt * 0xc2b2ae35u) ^ (c * 0x7feb352du));
        const float phase_offset = 2.0f * kPi * static_cast<float>(phase_seed & 0xFFFFu) / static_cast<float>(0x10000u);

        for (std::uint32_t k = 0; k < cfg_.q; ++k) {
            const float phase =
                2.0f * kPi * static_cast<float>((static_cast<std::uint64_t>(slope) * k) % cfg_.q) / static_cast<float>(cfg_.q)
                + phase_offset;
            codes_[static_cast<std::size_t>(c) * cfg_.q + k] = cis_mub(phase);
        }
    }
}

} // namespace holoram

# Follow-up Implementation Commands

Use the staged commands from the chat in order:

1. holoram-core codebooks and coherence
2. holoram-core dense/sparse codecs
3. holoram-core demix: matched, MMSE, SIC
4. holoram-core substrate, slot policy, WriteMap/WAL
5. holoram-core CUDA substrate and kernels
6. holovram-runtime simulator
7. holovram-runtime CUDA backend
8. holovram-runtime Vulkan sparse backend
9. holovram-runtime D3D12 backend
10. hololinux-integration queue device and daemon
11. hololinux-integration kernel-safe policy and stats bridge
12. hololinux-integration exact zswap backend
13. final hard review and optimization pass

Every command should include:

- Budget tokens based on complexity requirements if that is allowed.
- If you are going to run out of space ask me to continue.
